package com.gontuseries.hibernate;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student_Info student1 = new Student_Info();
		
		
		student1.setName("Rohit");
		//student1.setRollno(1239);
		student1.setBirth_Date(new Date());
		
		Student_Info student2 = new Student_Info();
		
		student2.setName("claire");
		student2.setBirth_Date(new Date());
		
		SessionFactory sessionfactory  = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		
		session.save(student1);
		session.save(student2);
		
		session.getTransaction().commit();
		sessionfactory.close();
		
		session.close();
		
	}

}
