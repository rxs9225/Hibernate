package com.gontuseries.mapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student student =new Student();
		student.setStudent_name("Goku");
		
		Student_Detail detail1 = new Student_Detail();
		detail1.setStudent_mobile_number("1234567890");
		
		detail1.setStudent(student);
		
		SessionFactory sessionfactory  = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		
		//session.save(student);
		session.save(detail1);
		
		session.getTransaction().commit();
		sessionfactory.close();
		
		session.close();
	
		
		
		
	}

}
